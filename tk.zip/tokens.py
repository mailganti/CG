# controller/routes/tokens.py - Complete SSL-compatible version

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field, validator
from typing import Optional
import logging
import secrets
import os
import re

from controller.db.db import get_db
from controller.deps import verify_token, require_admin

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/tokens", tags=["tokens"])

# SSL Configuration
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"

# Valid roles
VALID_ROLES = ["admin", "operator", "viewer", "agent"]


# ==================== Request Models ====================

class CreateTokenRequest(BaseModel):
    token_name: str = Field(..., min_length=2, max_length=100)
    role: str = Field(..., pattern=r'^(admin|operator|viewer|agent)$')
    description: str = Field(default="", max_length=500)
    
    @validator('token_name')
    def validate_token_name(cls, v):
        """Token name must be alphanumeric with hyphens/underscores"""
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Token name must contain only letters, numbers, hyphens, and underscores')
        return v


class UpdateTokenRequest(BaseModel):
    description: Optional[str] = Field(None, max_length=500)
    role: Optional[str] = Field(None, pattern=r'^(admin|operator|viewer|agent)$')


# ==================== Endpoints ====================

@router.get("")
@router.get("/")
async def list_tokens(
    limit: Optional[int] = None,
    include_revoked: bool = True,
    role: Optional[str] = None,
    token: dict = Depends(verify_token)
):
    """
    List all tokens (token values are hidden for security)
    
    Query params:
    - limit: Maximum number of tokens to return
    - include_revoked: Include revoked tokens (default: true)
    - role: Filter by role (admin, operator, viewer, agent)
    
    Accessible by: admin, operator, viewer (any authenticated user)
    """
    try:
        db = get_db()
        tokens = db.list_tokens(limit=limit, include_revoked=include_revoked)
        
        # Filter by role if specified
        if role:
            if role not in VALID_ROLES:
                raise HTTPException(status_code=400, detail=f"Invalid role: {role}")
            tokens = [t for t in tokens if t.get('role') == role]
        
        # Remove token_value for security (except for current user viewing their own)
        for t in tokens:
            # Only show partial token value (first 10 and last 5 chars)
            if 'token_value' in t and t['token_value']:
                full_token = t['token_value']
                if len(full_token) > 15:
                    t['token_value_preview'] = f"{full_token[:10]}...{full_token[-5:]}"
                else:
                    t['token_value_preview'] = f"{full_token[:5]}..."
            t.pop('token_value', None)
            t.pop('token_hash', None)
        
        logger.debug(f"Listed {len(tokens)} tokens (user: {token.get('token_name', 'unknown')})")
        
        return {
            "tokens": tokens,
            "count": len(tokens),
            "ssl_enabled": SSL_ENABLED
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing tokens: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{token_name}")
async def get_token(
    token_name: str,
    token: dict = Depends(verify_token)
):
    """
    Get token details (without token value for security)
    
    Accessible by: admin, operator, viewer (any authenticated user)
    """
    db = get_db()
    token_data = db.get_token(token_name)
    
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    # Remove sensitive data
    token_data.pop('token_hash', None)
    
    # Show partial token value
    if 'token_value' in token_data and token_data['token_value']:
        full_token = token_data['token_value']
        if len(full_token) > 15:
            token_data['token_value_preview'] = f"{full_token[:10]}...{full_token[-5:]}"
        else:
            token_data['token_value_preview'] = f"{full_token[:5]}..."
    token_data.pop('token_value', None)
    
    logger.debug(f"Retrieved token: {token_name} (user: {token.get('token_name', 'unknown')})")
    
    return token_data


@router.post("")
@router.post("/")
async def create_token(
    request: CreateTokenRequest,
    token: dict = Depends(require_admin)
):
    """
    Create a new API token
    
    Accessible by: admin only
    
    ⚠️ WARNING: Token value is only shown once! Save it immediately.
    """
    db = get_db()
    
    # Check if token name already exists
    existing = db.get_token(request.token_name)
    if existing:
        raise HTTPException(
            status_code=409,
            detail=f"Token '{request.token_name}' already exists"
        )
    
    # Generate secure random token
    token_value = secrets.token_urlsafe(32)
    
    try:
        token_data = db.create_token(
            token_name=request.token_name,
            token_value=token_value,
            role=request.role,
            description=request.description
        )
        
        logger.info(f"Token created: {request.token_name} (role: {request.role}) by {token.get('token_name', 'unknown')} (SSL: {SSL_ENABLED})")
        
        # Determine usage instructions based on role
        if request.role == "admin":
            usage_header = "X-Admin-Token"
        elif request.role == "agent":
            usage_header = "X-Agent-Token"
        else:
            usage_header = "X-Admin-Token"  # operator/viewer use admin header
        
        # Return token value only on creation (user must save it!)
        return {
            "message": "Token created successfully",
            "token_name": request.token_name,
            "token_value": token_value,  # ⚠️ Only shown once!
            "role": request.role,
            "ssl_enabled": SSL_ENABLED,
            "created_at": token_data.get('created_at'),
            "warning": "⚠️ SAVE THIS TOKEN! It will not be shown again.",
            "usage_example": f"curl -H '{usage_header}: {token_value}' https://your-controller/api/...",
            "recommended_storage": "Store in .env file or secure secrets manager"
        }
        
    except Exception as e:
        logger.error(f"Error creating token '{request.token_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create token: {str(e)}")


@router.put("/{token_name}")
async def update_token(
    token_name: str,
    request: UpdateTokenRequest,
    token: dict = Depends(require_admin)
):
    """
    Update token details (description and/or role)
    
    Accessible by: admin only
    
    Note: Cannot update token value for security. Create new token if needed.
    """
    db = get_db()
    
    # Check if token exists
    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    try:
        # Update only provided fields
        update_data = {}
        if request.description is not None:
            update_data['description'] = request.description
        if request.role is not None:
            update_data['role'] = request.role
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Perform update (you'll need to implement update_token in db.py)
        db.update_token(
            token_name=token_name,
            description=update_data.get('description', token_data.get('description')),
            role=update_data.get('role', token_data.get('role'))
        )
        
        logger.info(f"Token updated: {token_name} by {token.get('token_name', 'unknown')}")
        
        # Return updated token (without value)
        updated_token = db.get_token(token_name)
        updated_token.pop('token_value', None)
        updated_token.pop('token_hash', None)
        
        return {
            "message": "Token updated successfully",
            "token": updated_token
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating token '{token_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update token: {str(e)}")


@router.post("/{token_name}/revoke")
async def revoke_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    """
    Revoke a token (soft delete - can be restored)
    
    Accessible by: admin only
    """
    db = get_db()
    
    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    if token_data.get('revoked') == 1:
        raise HTTPException(status_code=400, detail="Token is already revoked")
    
    try:
        db.revoke_token(token_name)
        
        logger.info(f"Token revoked: {token_name} by {token.get('token_name', 'unknown')}")
        
        return {
            "message": "Token revoked successfully",
            "token_name": token_name,
            "note": "Token can be restored using /tokens/{token_name}/restore"
        }
    except Exception as e:
        logger.error(f"Error revoking token '{token_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to revoke token: {str(e)}")


@router.post("/{token_name}/restore")
async def restore_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    """
    Restore a revoked token
    
    Accessible by: admin only
    """
    db = get_db()
    
    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    if token_data.get('revoked') == 0:
        raise HTTPException(status_code=400, detail="Token is not revoked")
    
    try:
        db.restore_token(token_name)
        
        logger.info(f"Token restored: {token_name} by {token.get('token_name', 'unknown')}")
        
        return {
            "message": "Token restored successfully",
            "token_name": token_name
        }
    except Exception as e:
        logger.error(f"Error restoring token '{token_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to restore token: {str(e)}")


@router.delete("/{token_name}")
async def delete_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    """
    Delete a token permanently (hard delete - cannot be restored)
    
    Accessible by: admin only
    
    ⚠️ WARNING: This action cannot be undone!
    """
    db = get_db()
    
    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    try:
        db.delete_token(token_name)
        
        logger.warning(f"Token permanently deleted: {token_name} by {token.get('token_name', 'unknown')}")
        
        return {
            "message": "Token permanently deleted",
            "token_name": token_name,
            "warning": "This action cannot be undone"
        }
    except Exception as e:
        logger.error(f"Error deleting token '{token_name}': {e}")
        raise HTTPException(status_code=500, detail=f"Failed to delete token: {str(e)}")


@router.get("/{token_name}/usage")
async def get_token_usage(
    token_name: str,
    token: dict = Depends(verify_token)
):
    """
    Get usage statistics for a token (if tracking is implemented)
    
    Accessible by: admin, operator, viewer (any authenticated user)
    """
    db = get_db()
    
    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")
    
    # TODO: Implement usage tracking in database
    # For now, return basic info
    return {
        "token_name": token_name,
        "role": token_data.get('role'),
        "created_at": token_data.get('created_at'),
        "revoked": token_data.get('revoked') == 1,
        "note": "Usage tracking not yet implemented"
    }

