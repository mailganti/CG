# controller/routes/agents.py - Complete SSL-compatible version

"""
Agent routes with proper RBAC and SSL support
- Heartbeat: agent token only
- Registration/Management: admin token only
- Health checks: Support HTTP and HTTPS agents
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, validator, Field
from typing import Optional, List
import re
import socket
import logging
import os
import httpx

from controller.db.db import get_db
from controller.deps import verify_token, require_admin, require_agent

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agents", tags=["agents"])

# SSL Configuration
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"
SSL_VERIFY = os.getenv("SSL_VERIFY", "true").lower() == "true"
SSL_CA_CERTS = os.getenv("SSL_CA_CERTS", None)


# Pydantic models
class AgentRegister(BaseModel):
    agent_name: str = Field(..., min_length=2, max_length=255)
    host: str = Field(..., max_length=253)
    port: int = Field(..., ge=1, le=65535)
    status: str = Field(default="online")
    ssl_enabled: bool = Field(default=False)  # Track if agent uses SSL
    
    @validator('agent_name')
    def validate_agent_name(cls, v):
        """Agent name must be alphanumeric with hyphens/underscores"""
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Agent name must contain only letters, numbers, hyphens, and underscores')
        return v
    
    @validator('host')
    def validate_host(cls, v):
        """Validate host is valid IP or hostname"""
        # Check if it's a valid IPv4
        ipv4_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        # Check if it's a valid IPv6 (simplified)
        ipv6_pattern = r'^[0-9a-fA-F:]+$'
        # Check if it's a valid hostname
        hostname_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$'
        
        if not (re.match(ipv4_pattern, v) or re.match(ipv6_pattern, v) or re.match(hostname_pattern, v)):
            raise ValueError('Invalid host format')
        
        return v


class AgentUpdate(BaseModel):
    status: Optional[str] = Field(None, pattern='^(online|offline|maintenance)$')
    ssl_enabled: Optional[bool] = None


class HeartbeatRequest(BaseModel):
    agent_name: str


# Helper functions
def is_host_reachable(host: str) -> tuple[bool, str]:
    """Check if host is reachable via DNS"""
    try:
        # Simple socket connection test
        socket.getaddrinfo(host, None)
        return True, "Host is reachable"
    except socket.gaierror:
        return False, "Host not reachable or DNS resolution failed"


def resolve_hostname(host: str) -> tuple[bool, str]:
    """Resolve hostname to IP"""
    try:
        ip = socket.gethostbyname(host)
        return True, f"Resolved to {ip}"
    except socket.gaierror:
        return False, "DNS resolution failed"


async def check_agent_health(host: str, port: int, ssl_enabled: bool = False) -> tuple[bool, str]:
    """
    Check if agent is responding via HTTP health check
    Supports both HTTP and HTTPS
    """
    protocol = "https" if ssl_enabled else "http"
    url = f"{protocol}://{host}:{port}/health"
    
    # Configure SSL verification
    verify_ssl = SSL_VERIFY
    if SSL_VERIFY and SSL_CA_CERTS:
        verify_ssl = SSL_CA_CERTS
    
    try:
        async with httpx.AsyncClient(timeout=5.0, verify=verify_ssl) as client:
            response = await client.get(url)
            if response.status_code == 200:
                data = response.json()
                return True, f"Agent is healthy: {data.get('status', 'ok')}"
            else:
                return False, f"Agent returned status {response.status_code}"
    except httpx.ConnectError:
        return False, "Cannot connect to agent"
    except httpx.TimeoutException:
        return False, "Agent health check timeout"
    except httpx.RequestError as e:
        return False, f"Request error: {str(e)}"
    except Exception as e:
        return False, f"Health check failed: {str(e)}"


# Routes

@router.get("")
async def list_agents(
    limit: Optional[int] = Query(None, ge=1, le=1000),
    status: Optional[str] = Query(None, pattern='^(online|offline|maintenance)$'),
    user: dict = Depends(verify_token)  # Any authenticated user can list
):
    """
    List all agents with real-time status
    
    Anyone can view agents (admin, operator, viewer)
    """
    db = get_db()
    
    # Use list_agents_with_status for real-time status calculation
    agents = db.list_agents_with_status(limit=limit, status=status)
    
    logger.debug(f"Listed {len(agents)} agents (user: {user.get('token_name', 'unknown')})")
    
    return {
        "agents": agents,
        "count": len(agents),
        "ssl_enabled": SSL_ENABLED
    }


@router.get("/{agent_name}")
async def get_agent(
    agent_name: str,
    user: dict = Depends(verify_token)  # Any authenticated user can view
):
    """
    Get specific agent details with real-time status
    
    Anyone can view agents (admin, operator, viewer)
    """
    db = get_db()
    
    agent = db.get_agent(agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    
    # Add real-time status
    status = db.get_agent_status(agent_name, timeout_seconds=60)
    agent['status'] = status
    
    if status == 'online':
        agent['status_reason'] = f"Last seen {agent.get('last_seen', 'unknown')}"
    else:
        agent['status_reason'] = "No recent heartbeat"
    
    # Add protocol information
    ssl_enabled = agent.get('ssl_enabled', False)
    protocol = "https" if ssl_enabled else "http"
    agent['endpoint'] = f"{protocol}://{agent['host']}:{agent['port']}"
    
    logger.debug(f"Retrieved agent: {agent_name} (user: {user.get('token_name', 'unknown')})")
    
    return agent


@router.get("/{agent_name}/health")
async def check_agent_health_endpoint(
    agent_name: str,
    user: dict = Depends(verify_token)  # Any authenticated user can check health
):
    """
    Check agent health via HTTP/HTTPS health endpoint
    
    Supports both HTTP and HTTPS agents
    """
    db = get_db()
    
    agent = db.get_agent(agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    
    ssl_enabled = agent.get('ssl_enabled', False)
    is_healthy, message = await check_agent_health(
        agent['host'], 
        agent['port'],
        ssl_enabled
    )
    
    protocol = "https" if ssl_enabled else "http"
    endpoint = f"{protocol}://{agent['host']}:{agent['port']}/health"
    
    logger.info(f"Health check for {agent_name}: {'healthy' if is_healthy else 'unhealthy'} - {message}")
    
    return {
        "agent_name": agent_name,
        "healthy": is_healthy,
        "message": message,
        "protocol": protocol,
        "ssl_enabled": ssl_enabled,
        "endpoint": endpoint,
        "timestamp": "now"
    }


@router.post("")
@router.post("/register")
async def register_agent(
    agent: AgentRegister,
    validate_connectivity: bool = Query(False),
    validate_health: bool = Query(False),
    user: dict = Depends(require_admin)  # ADMIN ONLY for registration
):
    """
    Register a new agent
    
    **REQUIRES ADMIN TOKEN** - Only admins can register agents
    
    This prevents rogue agents from self-registering
    Supports both HTTP and HTTPS agents
    
    Query params:
    - validate_connectivity: Check if host is reachable (default: false)
    - validate_health: Check agent health endpoint (default: false)
    """
    db = get_db()
    
    # Validate connectivity if requested
    if validate_connectivity:
        reachable, msg = is_host_reachable(agent.host)
        if not reachable:
            logger.warning(f"Agent {agent.agent_name} host not reachable: {msg}")
            # Don't fail, just warn
    
    # Validate health if requested
    if validate_health:
        is_healthy, health_msg = await check_agent_health(
            agent.host, 
            agent.port,
            agent.ssl_enabled
        )
        if not is_healthy:
            logger.warning(f"Agent {agent.agent_name} health check failed: {health_msg}")
            # Don't fail, just warn
    
    # Check if agent already exists
    existing = db.get_agent(agent.agent_name)
    
    # Check if host:port combination already exists
    existing_host_port = db.get_agent_by_host_port(agent.host, agent.port)
    
    if existing:
        # Same agent name exists
        if existing_host_port and existing_host_port['agent_name'] == agent.agent_name:
            # Same agent, same host:port - just update
            logger.info(f"Agent {agent.agent_name} re-registering with same host:port")
            registered = db.register_agent(
                agent_name=agent.agent_name,
                host=agent.host,
                port=agent.port,
                status=agent.status,
                ssl_enabled=agent.ssl_enabled
            )
        elif existing_host_port and existing_host_port['agent_name'] != agent.agent_name:
            # Different agent trying to use same host:port
            raise HTTPException(
                status_code=409,
                detail=f"Host:port {agent.host}:{agent.port} already in use by agent '{existing_host_port['agent_name']}'"
            )
        else:
            # Same agent name, different host:port (agent moved)
            logger.info(f"Agent {agent.agent_name} moved to new host:port")
            registered = db.register_agent(
                agent_name=agent.agent_name,
                host=agent.host,
                port=agent.port,
                status=agent.status,
                ssl_enabled=agent.ssl_enabled
            )
    else:
        # New agent
        if existing_host_port:
            # New agent name but host:port already used
            raise HTTPException(
                status_code=409,
                detail=f"Host:port {agent.host}:{agent.port} already in use by agent '{existing_host_port['agent_name']}'"
            )
        
        # Register new agent
        registered = db.register_agent(
            agent_name=agent.agent_name,
            host=agent.host,
            port=agent.port,
            status=agent.status,
            ssl_enabled=agent.ssl_enabled
        )
    
    protocol = "https" if agent.ssl_enabled else "http"
    logger.info(f"Agent {agent.agent_name} registered at {protocol}://{agent.host}:{agent.port} by {user.get('token_name', 'unknown')}")
    
    return {
        "message": "Agent registered successfully",
        "agent": registered,
        "endpoint": f"{protocol}://{agent.host}:{agent.port}"
    }


@router.post("/heartbeat")
async def agent_heartbeat(
    heartbeat: HeartbeatRequest,
    user: dict = Depends(require_agent)  # AGENT TOKEN ONLY
):
    """
    Receive heartbeat from agent
    
    **REQUIRES AGENT TOKEN** - Uses X-Agent-Token header
    
    This endpoint should ONLY be called by agents with agent tokens
    """
    db = get_db()
    
    try:
        # Verify agent exists
        agent = db.get_agent(heartbeat.agent_name)
        if not agent:
            logger.error(f"Heartbeat from unregistered agent: {heartbeat.agent_name}")
            raise HTTPException(
                status_code=404,
                detail=f"Agent {heartbeat.agent_name} not registered. Admin must register first."
            )
        
        # Update heartbeat timestamp
        try:
            success = db.update_agent_heartbeat(heartbeat.agent_name)
        except AttributeError as e:
            # Method doesn't exist, try alternative
            logger.error(f"update_agent_heartbeat method not found: {e}")
            logger.info("Attempting to use register_agent to update heartbeat")
            
            # Fallback: re-register agent to update last_seen
            db.register_agent(
                agent_name=heartbeat.agent_name,
                host=agent['host'],
                port=agent['port'],
                status='online',
                ssl_enabled=agent.get('ssl_enabled', False)
            )
            success = True
        
        if not success:
            logger.error(f"Failed to update heartbeat for {heartbeat.agent_name}")
            raise HTTPException(status_code=500, detail="Failed to update heartbeat")
        
        logger.debug(f"Heartbeat received from {heartbeat.agent_name}")
        
        return {
            "status": "ok",
            "agent_name": heartbeat.agent_name,
            "timestamp": "updated",
            "ssl_enabled": SSL_ENABLED
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in heartbeat from {heartbeat.agent_name}: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error processing heartbeat: {str(e)}"
        )


@router.put("/{agent_name}/status")
async def update_agent_status(
    agent_name: str,
    update: AgentUpdate,
    user: dict = Depends(require_admin)  # ADMIN ONLY
):
    """
    Update agent status and/or SSL configuration
    
    **REQUIRES ADMIN TOKEN** - Only admins can manually change agent properties
    """
    db = get_db()
    
    agent = db.get_agent(agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    
    # Update status if provided
    if update.status:
        success = db.update_agent_status(agent_name, update.status)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to update status")
        logger.info(f"Agent {agent_name} status updated to {update.status} by {user.get('token_name', 'unknown')}")
    
    # Update SSL setting if provided
    if update.ssl_enabled is not None:
        # You'll need to implement update_agent_ssl in db.py
        try:
            db.update_agent_ssl(agent_name, update.ssl_enabled)
            logger.info(f"Agent {agent_name} SSL setting updated to {update.ssl_enabled} by {user.get('token_name', 'unknown')}")
        except AttributeError:
            logger.warning("update_agent_ssl not implemented in database")
    
    return db.get_agent(agent_name)


@router.delete("/{agent_name}")
async def deregister_agent(
    agent_name: str,
    user: dict = Depends(require_admin)  # ADMIN ONLY
):
    """
    Deregister an agent
    
    **REQUIRES ADMIN TOKEN** - Only admins can deregister agents
    """
    db = get_db()
    
    agent = db.get_agent(agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    
    success = db.deregister_agent(agent_name)
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to deregister agent")
    
    logger.info(f"Agent {agent_name} deregistered by {user.get('token_name', 'unknown')}")
    
    return {
        "status": "deleted", 
        "agent_name": agent_name,
        "message": "Agent deregistered successfully"
    }


@router.post("/{agent_name}/ping")
async def ping_agent(
    agent_name: str,
    user: dict = Depends(verify_token)  # Any authenticated user
):
    """
    Ping agent to check if it's reachable
    
    Performs both DNS check and health endpoint check
    """
    db = get_db()
    
    agent = db.get_agent(agent_name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
    
    # Check DNS reachability
    reachable, dns_msg = is_host_reachable(agent['host'])
    
    # Check health endpoint
    ssl_enabled = agent.get('ssl_enabled', False)
    is_healthy, health_msg = await check_agent_health(
        agent['host'],
        agent['port'],
        ssl_enabled
    )
    
    protocol = "https" if ssl_enabled else "http"
    
    logger.info(f"Ping agent {agent_name}: DNS={reachable}, Health={is_healthy}")
    
    return {
        "agent_name": agent_name,
        "host": agent['host'],
        "port": agent['port'],
        "protocol": protocol,
        "dns_reachable": reachable,
        "dns_message": dns_msg,
        "health_check": is_healthy,
        "health_message": health_msg,
        "overall_status": "online" if (reachable and is_healthy) else "offline"
    }
