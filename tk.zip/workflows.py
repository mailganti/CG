# controller/routes/workflows.py - SSL-compatible (FINAL FIXED)

from fastapi import APIRouter, HTTPException, Depends, Body, BackgroundTasks,Request
from pydantic import BaseModel
from typing import List, Optional
import logging
import uuid
import os
import httpx

from controller.db.db import get_db
from controller.deps import verify_token, require_admin, require_approver
from controller.deps import verify_token, verify_approver_jwt, require_execution_token
from controller.emailer import send_email

logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/workflows", tags=["workflows"])

# SSL Configuration
SSL_ENABLED = os.getenv("SSL_ENABLED", "false").lower() == "true"
SSL_VERIFY = os.getenv("SSL_VERIFY", "true").lower() == "true"
SSL_CA_CERTS = os.getenv("SSL_CA_CERTS", None)


router = APIRouter(prefix="/workflows", tags=["workflows"])

class ReexecRequest(BaseModel):
    note: Optional[str] = None
    requester_email: Optional[str] = None

@router.post("/{workflow_id}/reexec/request")
async def request_reexecution(workflow_id: str, payload: ReexecRequest, user: dict = Depends(verify_token)):
    """
    Request approval for (re-)execution of a workflow.
    Creates an approval request and emails the approver(s).
    """
    db = get_db()
    wf = db.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    # create request
    requester = user.get('username') or user.get('token_name') or 'unknown'
    requester_email = payload.requester_email or wf.get('notify_email') or None
    req = db.create_execution_approval_request(workflow_id, requester, requester_email, payload.note or "")

    # Email the approver(s)
    # Prefer workflow.notify_email if present; otherwise fail safe: return request created and log
    approver_target = wf.get('notify_email') or requester_email
    if not approver_target:
        logger.warning("No approver email configured for workflow %s", workflow_id)
        return {"message": "Approval request created", "request": req}

    # Construct approval URL - approvers must be authenticated via JWT in our design
    api_host = os.getenv("API_HOST", "http://localhost:8000")
    approve_url = f"{api_host}/api/workflows/{workflow_id}/reexec/approve?request_id={req['id']}"

    html = f"""
    <p>A request to execute workflow <strong>{workflow_id}</strong> was created by {requester}.</p>
    <p>Note: {payload.note or '(none)'}</p>
    <p>Approver must authenticate via web UI (JWT) and then call the approve endpoint or use the dashboard.</p>
    <p>To approve (requires approver JWT): <code>POST {approve_url}</code></p>
    """

    send_email(approver_target, f"Execution approval required for {workflow_id}", html)
    return {"message": "Approval request created and approver notified", "request": req}


class ApprovePayload(BaseModel):
    request_id: int

@router.post("/{workflow_id}/reexec/approve")
async def approve_reexecution(workflow_id: str, payload: ApprovePayload, approver_jwt: dict = Depends(verify_approver_jwt)):
    """
    Approver approves a re-execution. Approver authenticates with JWT (Authorization: Bearer <jwt>).
    On success: an execution token is created and emailed to the original requester.
    """
    db = get_db()
    req = db.get_execution_approval_request(payload.request_id)
    if not req:
        raise HTTPException(status_code=404, detail="Approval request not found")
    if req['workflow_id'] != workflow_id:
        raise HTTPException(status_code=400, detail="Mismatched workflow")

    if req['status'] != 'pending':
        raise HTTPException(status_code=400, detail="Request not pending")

    approver = approver_jwt.get('sub') or approver_jwt.get('username') or approver_jwt.get('email') or 'approver'
    token_row = db.approve_execution_request(payload.request_id, approver)
    if not token_row:
        raise HTTPException(status_code=500, detail="Failed to approve request")

    # Email token to requester (use stored requester_email in request or workflow.notify_email)
    requester_email = req.get('requester_email') or (db.get_workflow(workflow_id) or {}).get('notify_email')
    if requester_email:
        html = f"""
        <p>Your execution request for workflow <strong>{workflow_id}</strong> has been approved.</p>
        <p>Use the following one-time execution token to run the workflow (valid until {token_row.get('expires_at')}):</p>
        <pre>{token_row.get('token')}</pre>
        <p>Call the execute API with header <code>X-Execution-Token</code> containing the token.</p>
        """
        send_email(requester_email, f"Execution token for {workflow_id}", html)

    return {"message": "Approved and token issued", "token_id": token_row.get('id')}


class ExecutePayload(BaseModel):
    # payload for execution API if any extra params
    pass

#@router.post("/{workflow_id}/execute")
#async def execute_workflow(workflow_id: str, payload: Optional[ExecutePayload] = None, token_row = Depends(require_execution_token(workflow_id)), user: dict = Depends(verify_token)):
#    """
#    Execute workflow with a valid X-Execution-Token header.
#    Requires token validated by dependency.
#    """
#    db = get_db()
#    wf = db.get_workflow(workflow_id)
#    if not wf:
#        raise HTTPException(status_code=404, detail="Workflow not found")
#
#    # Create execution record
#    executor = user.get('username') or user.get('token_name') or 'unknown'
#    exec_id = db.create_execution_record(workflow_id, executor, status="running", log_file=None)
#
#    # call script runner (scripts.py) -- keep behavior same as before
#    # Example: delegate to scripts module responsible to run the actual script by workflow['script_id']
#    from controller.scripts import run_workflow_script
#    try:
#        result = run_workflow_script(workflow_id, wf, exec_id)
#        db.complete_execution_record(exec_id, status="success", result_json=json.dumps(result) if result else "{}")
#        return {"message": "Execution started", "execution_id": exec_id}
#    except Exception as e:
#        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": str(e)}))
#        raise HTTPException(status_code=500, detail=f"Execution failed: {e}")
#

# ==================== Request Models ====================

class CreateWorkflowRequest(BaseModel):
    script_id: str
    targets: List[str]
    requestor: str
    reason: str
    required_approval_levels: int = 1
    ttl_minutes: int = 60
    notify_email: str = ""


class ApproveWorkflowRequest(BaseModel):
    approver: str
    level: int = 1


class ExecuteWorkflowRequest(BaseModel):
    """
    Optional payload when executing a workflow.

    This is intentionally loose. We only care about:
    - parameters: dict for script parameters
    - environment: dict of env vars
    - timeout: optional override
    """
    parameters: Optional[dict] = None
    environment: Optional[dict] = None
    timeout: Optional[int] = None


# ==================== Helper Functions ====================

async def notify_agent_of_workflow(
    agent_host: str,
    agent_port: int,
    workflow_id: str,
    ssl_enabled: bool = False
) -> bool:
    """
    Notify agent that a workflow is ready for execution (supports HTTP/HTTPS)
    Not currently used by the direct-execution path but kept for future use.
    """
    protocol = "https" if ssl_enabled else "http"
    url = f"{protocol}://{agent_host}:{agent_port}/execute-workflow"

    verify_ssl = SSL_VERIFY
    if SSL_VERIFY and SSL_CA_CERTS:
        verify_ssl = SSL_CA_CERTS

    try:
        async with httpx.AsyncClient(timeout=10.0, verify=verify_ssl) as client:
            response = await client.post(url, json={"workflow_id": workflow_id})
            return response.status_code == 200
    except Exception as e:
        logger.error(f"Failed to notify agent at {url}: {e}")
        return False


# ==================== Endpoints ====================

@router.get("")
@router.get("/")
async def list_workflows(
    limit: Optional[int] = None,
    status: Optional[str] = None,
    token: dict = Depends(verify_token)
):
    """
    List workflows with optional limit and status filter.
    Used by dashboard UI.
    """
    try:
        db = get_db()
        workflows = db.list_workflows(limit=limit, status=status)
        return {
            "workflows": workflows,
            "count": len(workflows),
            "ssl_enabled": SSL_ENABLED
        }
    except Exception as e:
        logger.error(f"Error listing workflows: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{workflow_id}")
async def get_workflow(
    workflow_id: str,
    token: dict = Depends(verify_token)
):
    """Return a workflow by ID."""
    db = get_db()
    workflow = db.get_workflow(workflow_id)

    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    return workflow


# ==================== CREATE WORKFLOW ====================

@router.post("")
@router.post("/")
async def create_workflow(
    request: CreateWorkflowRequest,
    token: dict = Depends(verify_token)
):
    """
    Create a new workflow (used by UI).

    Stores:
    - script_id
    - targets (saved as targets_json in DB)
    - requestor, reason, approvals, notify_email, ttl
    """
    db = get_db()

    workflow_id = f"wf_{uuid.uuid4().hex[:12]}"

    try:
        workflow = db.create_workflow(
            workflow_id=workflow_id,
            script_id=request.script_id,
            targets=request.targets,
            requestor=request.requestor,
            required_levels=request.required_approval_levels,
            notify_email=request.notify_email,
            ttl_minutes=request.ttl_minutes,
            reason=request.reason
        )

        db.add_audit(
            workflow_id=workflow_id,
            action="created",
            user=request.requestor,
            note=f"Workflow created: {request.reason}"
        )

        logger.info(f"Workflow created: {workflow_id} (SSL: {SSL_ENABLED})")
        return workflow

    except Exception as e:
        logger.error(f"Error creating workflow: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ==================== APPROVAL ====================

@router.post("/{workflow_id}/approve")
async def approve_workflow(
    workflow_id: str,
    request: ApproveWorkflowRequest,
    user: dict = Depends(require_approver)
):
    """Approve a workflow."""
    db = get_db()

    workflow = db.get_workflow(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    if workflow["status"] != "pending":
        raise HTTPException(
            status_code=400,
            detail=f"Workflow is already {workflow['status']}"
        )

    success = db.add_approval(workflow_id, request.approver, request.level)
    if not success:
        raise HTTPException(status_code=400, detail="Already approved by this user")

    # Check approvals
    workflow = db.get_workflow(workflow_id)
    approvals = workflow.get("approvals", [])

    if len(approvals) >= workflow["required_approval_levels"]:
        db.update_workflow_status(workflow_id, "approved")
        db.add_audit(
            workflow_id=workflow_id,
            action="fully_approved",
            user=request.approver,
            note=f"Workflow fully approved"
        )

        logger.info(f"Workflow approved: {workflow_id}")

        return {
            "message": "Workflow fully approved",
            "workflow_id": workflow_id,
            "status": "approved"
        }

    # Partial approval
    db.add_audit(
        workflow_id=workflow_id,
        action="partial_approval",
        user=request.approver,
        note=f"Approval {len(approvals)}/{workflow['required_approval_levels']}"
    )

    return {
        "message": "Approval added",
        "workflow_id": workflow_id,
        "approvals": len(approvals),
        "required": workflow["required_approval_levels"]
    }


# ==================== EXECUTION (FINAL FIXED) ====================

@router.post("/{workflow_id}/execute")
async def execute_workflow(
    workflow_id: str,
    background_tasks: BackgroundTasks,
    request: Optional[ExecuteWorkflowRequest] = Body(default=None),
    user: dict = Depends(verify_token)
):
    """
    Execute the workflow's script via the existing scripts.execute_script route.

    This:
    - Loads workflow from DB
    - Uses workflow['targets'] (populated from targets_json)
    - Builds an ExecuteScriptRequest instance
    - Calls controller.routes.scripts.execute_script(...)
    """
    db = get_db()

    workflow = db.get_workflow(workflow_id)
    if not workflow or workflow["status"] != "approved":
        raise HTTPException(status_code=400, detail="Workflow not approved")

    script_id = workflow.get("script_id")
    if not script_id:
        raise HTTPException(status_code=400, detail="Workflow has no script")

    targets = workflow.get("targets") or []
    if not targets:
        raise HTTPException(status_code=400, detail="Workflow has no targets")

    # Import the Pydantic model and executor from scripts router
    from controller.routes.scripts import ExecuteScriptRequest, execute_script

    exec_request = ExecuteScriptRequest(
        target_agents=targets,
        parameters=(request.parameters if request and request.parameters is not None else {}),
        environment=(request.environment if request and request.environment is not None else {}),
        timeout=(request.timeout if request and request.timeout is not None else None),
    )

    result = await execute_script(
        script_id=script_id,
        request=exec_request,
        background_tasks=background_tasks,
        user=user
    )

    return {
        "message": "Workflow executed",
        "workflow_id": workflow_id,
        "script_result": result
    }


# ==================== DELETE ====================

@router.delete("/{workflow_id}")
async def delete_workflow(
    workflow_id: str,
    token: dict = Depends(verify_token)
):
    db = get_db()

    workflow = db.get_workflow(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    db.delete_workflow(workflow_id)
    logger.info(f"Workflow deleted: {workflow_id}")

    return {"message": "Workflow deleted", "workflow_id": workflow_id}


# ==================== AUDIT LOGS ====================

@router.get("/{workflow_id}/audit")
async def get_workflow_audit(
    workflow_id: str,
    token: dict = Depends(verify_token)
):
    db = get_db()

    workflow = db.get_workflow(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail="Workflow not found")

    logs = db.get_audit_logs(workflow_id)

    return {
        "workflow_id": workflow_id,
        "audit_logs": logs,
        "count": len(logs)
    }
